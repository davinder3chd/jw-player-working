//Write a program that prints three items, such as the names of your three best friends
//or favorite movies, on three separate lines

#include<iostream>

using namespace std;

int main()
{
	// trolling
    string item1 = "KLETA";
    string item2 = "MAJKA";
    string item3 = "BALGARIQ";

    cout <<  item1 << " " << item2 << " " << item3;

    return 0;
}
