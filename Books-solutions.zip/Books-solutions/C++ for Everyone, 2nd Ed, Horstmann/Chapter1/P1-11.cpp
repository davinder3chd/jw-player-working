//Write a program that prints an animal speaking a greeting

#include<iostream>

using namespace std;

int main()
{
    cout << "    /\\_/\\     ----- \n";
    cout << "   ( ' ' )  / Hello \\ \n";
    cout << "   (  -  ) < Junior  | \n";
    cout << "    | | |   \\ Coder!/ \n";
    cout << "   (__|__)    ----- \n";

    return 0;
}
