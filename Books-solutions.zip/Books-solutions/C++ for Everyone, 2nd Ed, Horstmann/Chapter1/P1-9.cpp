//Write a program that prints a face

#include<iostream>

using namespace std;

int main()
{
    cout << "  /////\n";
    cout << " +-----+\n";
    cout << "(| o o |)\n";
    cout << " |  ^  |\n";
    cout << " | '-' |\n";
    cout << " +-----+\n";

    return 0;
}
