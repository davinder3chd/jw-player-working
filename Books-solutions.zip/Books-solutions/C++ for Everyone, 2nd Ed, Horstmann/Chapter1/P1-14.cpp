//Write a program that prints an imitation of a Piet Mondrian painting. (Search the
//	Internet if you are not familiar with his paintings.) Use character sequences such as
//	@@@ or  ::: to indicate different colors, and use - and | to form lines.

#include<iostream>


/* Reference:
http://upload.wikimedia.org/wikipedia/en/f/fe/Mondrian_Composition_II_in_Red,_Blue,_and_Yellow.jpg
 I suck at this :)
*/

using namespace std;

int main()
{
    cout << "@@@@@|:::::::::::::::::::\n";
    cout << "@@@@@|:::::::::::::::::::\n";
    cout << "@@@@@|:::::::::::::::::::\n";
    cout << "-----|:::::::::::::::::::\n";
    cout << "@@@@@|:::::::::::::::::::\n";
    cout << "@@@@@|:::::::::::::::::::\n";
    cout << "@@@@@|:::::::::::::::::::\n";
    cout << "-------------------------\n";
    cout << "#####|@@@@@@@@@@@@@@|@@@@\n";
    cout << "#####|@@@@@@@@@@@@@@|@@@@\n";
    cout << "#####|@@@@@@@@@@@@@@|----\n";
    cout << "#####|@@@@@@@@@@@@@@|YYYY\n";

    return 0;
}
