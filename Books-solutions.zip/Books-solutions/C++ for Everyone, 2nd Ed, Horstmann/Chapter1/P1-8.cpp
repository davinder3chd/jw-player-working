//Write a program that prints your name in large letters

#include<iostream>

using namespace std;

int main()
{
    cout <<  "**    *      *      **      *  ******\n";
    cout <<  "* *   *     * *     * *    **  *     \n";
    cout <<  "*  *  *    *   *    *  *  * *  *     \n";
    cout <<  "*   * *   * *** *   *   *   *  ******\n";
    cout <<  "*    **  *       *  *       *  *     \n";
    cout <<  "*     * *         * *       *  ******\n";

    return 0;
}
