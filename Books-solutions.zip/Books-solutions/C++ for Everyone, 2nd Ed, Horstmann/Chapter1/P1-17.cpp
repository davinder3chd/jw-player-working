﻿//Write a program that displays the following image, using characters such as / \ - | +
//for the lines.Write Ω as “Ohm”

#include <iostream>

using namespace std;

int main()
{
    cout << "        ___/\\  /\\  /\\  _______/\\  /\\  /\\  __" << "\n";
    cout << "       |     \\/  \\/  \\/   |     \\/  \\/  \\/  |" << "\n";
    cout << "       |     5kOhm        |       6kOhm     |" << "\n";
    cout << "       |                   \\                 \\" << "\n";
    cout << "      ---                  /                 /" << "\n";
    cout << " 12V | + |        10kOhm   \\          4kOhm  \\" << "\n";
    cout << "     | - |                 /                 /" << "\n";
    cout << "      ---                  \\                 \\" << "\n";
    cout << "       |                   /                 /" << "\n";
    cout << "       |                  |                 |" << "\n";
    cout << "       |                  |                 |" << "\n";
    cout << "       ---------------------------------------" << "\n";

   return 0;
}
