// write a program that prints a greeting of your choice, perhaps in another language

#include<iostream>

using std::cout;


int main()
{
    cout << "Hello stranger!";


    return 0;
}
