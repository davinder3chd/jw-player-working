//Printing a grid

#include<iostream>

using namespace std;

int main()
{
    string comb = "+--+--+--+\n|  |  |  |";
    string line = "+--+--+--+";

    cout << comb << "\n";
    cout << comb << "\n";
    cout << comb << "\n";
    cout << line;

    return 0;
}
