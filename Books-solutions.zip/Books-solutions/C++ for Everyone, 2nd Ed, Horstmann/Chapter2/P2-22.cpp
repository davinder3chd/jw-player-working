//Writing large letters

#include<iostream>

using namespace std;

int main()
{
    const string LETTER_H = "*   *\n*   *\n*****\n*   *\n*   *\n";
    const string LETTER_E = "*****\n*   \n***\n*\n*****\n";
    const string LETTER_L = "*\n*\n*\n*\n*****\n";
    const string LETTER_O = "  *\n * *\n*   *\n*   *\n * *\n  *\n";



    cout << LETTER_H << "\n";
    cout << LETTER_E << "\n";
    cout << LETTER_L << "\n";
    cout << LETTER_L << "\n";
    cout << LETTER_O;

    return 0;
}
