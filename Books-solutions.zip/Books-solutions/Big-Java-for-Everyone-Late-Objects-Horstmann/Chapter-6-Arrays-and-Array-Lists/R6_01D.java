import java.util.Arrays;

/*Write code that fills an array values with each set of numbers below.
0   0   0   0   0   0   0   0   0    0*/

public class R6_01D {
    public static void main(String[] args) {
        int[] numbers = new int[10];
        System.out.println(Arrays.toString(numbers));
    }
}
