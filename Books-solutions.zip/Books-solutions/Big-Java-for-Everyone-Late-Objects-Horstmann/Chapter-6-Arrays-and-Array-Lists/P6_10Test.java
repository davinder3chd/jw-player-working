import static org.junit.Assert.*;
import org.junit.Test;


public class P6_10Test {
//    @Test
//    public void testSameSetTrue() {
//        int[] a = { 1, 2, 3, 4 };
//        int[] b = { 1, 1, 2, 3, 4};
//        assertTrue(P6_10.sameSet(a, b));
//    }
}
