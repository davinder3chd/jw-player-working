import java.util.Arrays;

/*Write code that fills an array values with each set of numbers below.
1   4   9   16   9   7   4   9   11*/

public class R6_01E {
    public static void main(String[] args) {
        int[] numbers = {1, 4, 9, 16, 9, 7, 4, 9, 11};
        System.out.println(Arrays.toString(numbers));
    }
}
