
public class P2_18 {

    public static void main(String[] args) {
        final String LETTER_H = "*   *\n*   *\n*****\n*   *\n*   *\n";
        final String LETTER_E = "*****\n* \n*****\n* \n*****\n";
        final String LETTER_L = "* \n* \n* \n* \n*****\n";
        final String LETTER_O = "*****\n*   *\n*   *\n*   *\n*****\n";
        System.out.println(LETTER_H);
        System.out.println(LETTER_E);
        System.out.println(LETTER_L);
        System.out.println(LETTER_L);
        System.out.println(LETTER_O);
    }
}
