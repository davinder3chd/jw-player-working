//Write a program that prints the grid of a tic-tac-toe game.


public class P2_15 {
    public static void main(String[] args) {
        String comb = "\n+--+--+--+\n|  |  |  |";
        String line = "+--+--+--+";
        System.out.println(comb + comb + comb);
        System.out.println(line);
    }

}
