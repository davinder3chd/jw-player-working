import javax.swing.JFrame;


public class InvestmentFrameViewer2 {
    public static void main(String[] args) {
        JFrame investmentFrame = new InvestmentFrame2();
        investmentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        investmentFrame.setVisible(true);
    }
}
