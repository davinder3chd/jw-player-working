import javax.swing.JFrame;


public class ButtonViewer1 {
    public static void main(String[] args) {
        JFrame frame = new ButtonFrame1();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
