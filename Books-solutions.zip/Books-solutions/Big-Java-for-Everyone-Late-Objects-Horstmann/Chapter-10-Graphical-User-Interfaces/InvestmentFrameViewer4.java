import javax.swing.JFrame;


public class InvestmentFrameViewer4 {
    public static void main(String[] args) {
        JFrame investmentFrame = new InvestmentFrame4();
        investmentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        investmentFrame.setVisible(true);
    }
}
