/*Write a program that prints all power of 2 from 2 of power 0 up to 2 of power 20*/

public class P4_13 {
    public static void main(String[] args) {
	for (int i = 0; i < 21; i++) {
	    System.out.println(Math.pow(2, i));
	}
    }
}
