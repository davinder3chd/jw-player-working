package collections.bank;

public class Customer {
    private double arrivalTime;

    public Customer(double time) {
        this.arrivalTime = time;
    }

    public double getArrivalTime() {
        return this.arrivalTime;
    }
}
