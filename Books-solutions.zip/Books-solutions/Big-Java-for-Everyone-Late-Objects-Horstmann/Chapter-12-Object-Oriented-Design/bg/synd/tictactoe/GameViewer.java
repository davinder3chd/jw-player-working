package bg.synd.tictactoe;

import javax.swing.JFrame;

public class GameViewer {
    public static void main(String[] args) {
        JFrame frame = new GameFrame();
    }
}
