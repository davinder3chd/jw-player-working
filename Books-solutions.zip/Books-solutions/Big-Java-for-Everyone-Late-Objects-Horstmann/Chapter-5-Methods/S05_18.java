/*Implement a method shout that prints a line consisting of a string followed by
three exclamation marks. For example, shout("Hello") should print Hello!!! . The
method should not return a value.*/

public class S05_18 {
    public static void shout(String message) {
	System.out.println(message + "!!!");
    }
}
