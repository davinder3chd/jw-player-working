/*Write a method String getTimeName(int hours, int minutes) that returns the English
name for a point in time, such as "ten minutes past two" , "half past three" , "a quarter to
four" , or "five o'clock" . Assume that hours is between 1 and 12.
*/

public class P5_14 {
    public static String getTimeName(int hours, int minutes) {
        return "not implemented";
    }
}
