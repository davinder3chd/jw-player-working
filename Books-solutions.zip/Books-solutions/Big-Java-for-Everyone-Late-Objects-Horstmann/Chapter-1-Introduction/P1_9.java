//Write a program that prints a house.


public class P1_9 {

	public static void main(String[] args) {
		System.out.println("     /\\");
		System.out.println("    /  \\");
		System.out.println("   +----+ ");
		System.out.println("   | .-.| ");
		System.out.println("   | | ||");
		System.out.println("   +-+-++ ");
	}

}
