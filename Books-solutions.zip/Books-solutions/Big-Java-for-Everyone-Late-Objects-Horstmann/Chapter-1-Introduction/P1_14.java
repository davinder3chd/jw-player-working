// Show the message "Hello, name"


import javax.swing.JOptionPane;


public class P1_14 {

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Hello, github!");
	}

}
