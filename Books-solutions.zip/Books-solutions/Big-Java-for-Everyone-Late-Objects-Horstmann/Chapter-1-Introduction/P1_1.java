/*
Write a program that prints a greeting of your choice,
perhaps in a language other than English.
*/

public class P1_1 {
    public static void main(String[] args) {
        System.out.println("hello world");
    }
}