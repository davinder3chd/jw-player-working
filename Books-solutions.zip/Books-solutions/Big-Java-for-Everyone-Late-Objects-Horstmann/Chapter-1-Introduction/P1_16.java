// Modify the program P1_15.java so that the dialog continues.


import javax.swing.JOptionPane;

public class P1_16 {

	public static void main(String[] args) {
    	JOptionPane.showInputDialog("Hello, what would you like me to do?");
    	JOptionPane.showMessageDialog(null, "Sorry, can't do that!");
	}

}
