/*
Write a program that prints the product of the first
ten positive integers.
*/


public class P1_3 {
    public static void main(String[] args) {
        System.out.println(1 * 2 * 3 * 4 * 5 * 6 * 7 * 8 * 9 * 10);
    }
}
