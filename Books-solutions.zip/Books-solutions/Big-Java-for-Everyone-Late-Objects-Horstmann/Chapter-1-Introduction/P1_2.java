


//Write a program that prints the sum of the first ten positive integers.


public class P1_2 {
    public static void main(String[] args) {
        System.out.println(1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10);
    }
}
