var PlayerStates = {
  0: "UNKNOWN",
  1: "PLAYED_TO_END",
  2: "FORWARDED_TO_END",
  3: "ERRORED",
  4: "PLAYLIST_CHANGED",
  5: "USER_INITIATED"
};
