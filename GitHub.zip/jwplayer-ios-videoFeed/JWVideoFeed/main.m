//
//  main.m
//  JWVideoFeed
//
//  Created by Karim Mourra on 11/24/15.
//  Copyright © 2015 Karim Mourra. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
