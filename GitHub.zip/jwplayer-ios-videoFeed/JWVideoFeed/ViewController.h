//
//  ViewController.h
//  JWVideoFeed
//
//  Created by Karim Mourra on 11/24/15.
//  Copyright © 2015 Karim Mourra. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

